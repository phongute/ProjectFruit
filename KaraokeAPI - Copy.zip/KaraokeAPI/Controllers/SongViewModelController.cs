﻿using KaraokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KaraokeAPI.Controllers
{
    public class SongViewModelController : ApiController
    {
        Karaoke k = new Karaoke();
        public List<Singer> GetListSingerBySong(string id)
        {
            var query = (from si in k.Singers
                         join so in k.SongDetails on si.SingerID equals so.SingerID
                         where so.SongID == id
                         select si).ToList();
            List<Singer> lst = new List<Singer>();
            foreach (Singer si in query)
                lst.Add(new Singer
                {
                    SingerID = si.SingerID,
                    SingerName = si.SingerName,
                    Age = si.Age,
                });
            return lst;
        }

        [HttpGet]
        public List<SongViewModel> GetTopPostSong()
        {

            var query = k.Database.SqlQuery<SongViewModel>("select * from GetSongDistinct()").ToList();
            List<SongViewModel> lst = new List<SongViewModel>();

            foreach (var p in query)
            {
                lst.Add(new SongViewModel
                {
                    SongID = p.SongID,
                    SongName = p.SongName,
                    GenreID = p.GenreID,
                    GenreName = p.GenreName,
                    AuthorID = p.AuthorID,
                    AuthorName = p.AuthorName,
                    DatePost = p.DatePost,
                    ViewCount = 0,
                    ListSinger = GetListSingerBySong(p.SongID),
                });
            }

            List<SongViewModel> list = (from temp in lst
                                        where temp.DatePost > DateTime.Now.AddDays(-30)
                                        select temp).Take(10).ToList();
            return list;
        }
    }
}
