﻿using KaraokeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KaraokeAPI.Controllers
{
    public class LoginController : ApiController
    {
        Karaoke db= new Karaoke();
        public bool Login(string userName,string password)
        {
            int result = db.Users.Count(x => x.UserName == userName && x.Password == password);
            if (result > 0)
            {
                return true;
            }
            else
                return false;
        }
    }
}
