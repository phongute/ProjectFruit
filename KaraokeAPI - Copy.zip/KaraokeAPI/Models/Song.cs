namespace KaraokeAPI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Song")]
    public partial class Song
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Song()
        {
            SongDetails = new HashSet<SongDetail>();
        }

        [StringLength(50)]
        public string SongID { get; set; }

        [StringLength(50)]
        public string SongName { get; set; }

        [StringLength(50)]
        public string GenreID { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? DatePost { get; set; }

        public int? ViewCount { get; set; }

        public virtual Genre Genre { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SongDetail> SongDetails { get; set; }
    }
}
