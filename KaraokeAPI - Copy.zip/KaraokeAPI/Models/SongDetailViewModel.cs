﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeAPI.Models
{
    public class SongDetailViewModel
    {
        public string SongID { get; set; }
        public string AuthorID { get; set; }
        public string SingerID { get; set; }
    }
}