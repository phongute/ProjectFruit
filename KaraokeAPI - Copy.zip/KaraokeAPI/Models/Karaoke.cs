using System;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace KaraokeAPI.Models
{


    public partial class Karaoke : DbContext
    {
        public Karaoke()
            : base("name=Karaoke1")
        {
        }

        public virtual DbSet<Author> Authors { get; set; }
        public virtual DbSet<Genre> Genres { get; set; }
        public virtual DbSet<Singer> Singers { get; set; }
        public virtual DbSet<Song> Songs { get; set; }
        public virtual DbSet<SongDetail> SongDetails { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Author>()
                .HasMany(e => e.SongDetails)
                .WithRequired(e => e.Author)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Singer>()
                .HasMany(e => e.SongDetails)
                .WithRequired(e => e.Singer)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Song>()
                .HasMany(e => e.SongDetails)
                .WithRequired(e => e.Song)
                .WillCascadeOnDelete(false);
        }
    }
}
