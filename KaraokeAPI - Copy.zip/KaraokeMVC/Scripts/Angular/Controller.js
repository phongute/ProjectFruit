﻿/// <reference path="../angular.min.js" />  
/// <reference path="Modules.js" />  
/// <reference path="Services.js" />  

app.controller("SongController", function ($scope,$sce, Service) {

    GetAllSong();
    //To Get All Records  
    function GetAllSong() {
        var p = Service.getAllSong();
        p.then(function (pl) { $scope.myData = pl.data },
             function (errorPl) {
                 $log.error('Some Error in Getting Records.', errorPl);
             });
    }


    $scope.source = $sce.trustAsResourceUrl("https://www.youtube.com/embed/da6HVo6np5Y");

    $scope.changeSource = function (id) {
        $scope.source = $sce.trustAsResourceUrl("https://www.youtube.com/embed/" + id + "?autoplay=1");
    };
    //GetSongOfSinger(SingerID);
    $scope.GetSongOfSinger = function (SingerID) {
        var p = Service.GetSongOfSinger(SingerID);
        p.then(function (pl) { $scope.ListSongOfSinger = pl.data },
             function (errorPl) {
                 $log.error('Some Error in Getting Records.', errorPl);
             });
    }

    GetTopPost();
    function GetTopPost () {
        var p = Service.GetTopPost();
        p.then(function (pl) { $scope.ListTopPost = pl.data },
             function (errorPl) {
                 $log.error('Some Error in Getting Records.', errorPl);
             });
    }


    //Search
    $scope.SongName = false;
    $scope.SingerName = false;
    $scope.GenreName = false;

    $scope.filter = "$";
    $scope.search = {
        SongName: '',
        SingerName: '',
        GenreName:'',
        $: ''
    };
    $scope.changeFilterTo = function (pr) {


        $scope.filter = pr;
        $scope.search = {
            SongName: '',
            SingerName: '',
            GenreName: '',
            $: ''
        };
    }





    ////To Clear all input controls.  
    //function ClearModels() {
    //    $scope.OperType = 1;
    //    $scope.StudentID = "";
    //    $scope.Name = "";
    //    $scope.Email = "";
    //    $scope.Class = "";
    //    $scope.EnrollYear = "";
    //    $scope.City = "";
    //    $scope.Country = "";
    //}

    ////To Create new record and Edit an existing Record.  
    //$scope.save = function () {
    //    var Student = {
    //        Name: $scope.Name,
    //        Email: $scope.Email,
    //        Class: $scope.Class,
    //        EnrollYear: $scope.EnrollYear,
    //        City: $scope.City,
    //        Country: $scope.Country
    //    };
    //    if ($scope.OperType === 1) {
    //        var promisePost = CRUD_AngularJs_RESTService.post(Student);
    //        promisePost.then(function (pl) {
    //            $scope.StudentID = pl.data.StudentID;
    //            GetAllRecords();

    //            ClearModels();
    //        }, function (err) {
    //            console.log("Some error Occured" + err);
    //        });
    //    } else {
    //        //Edit the record      
    //        debugger;
    //        Student.StudentID = $scope.StudentID;
    //        var promisePut = CRUD_AngularJs_RESTService.put($scope.StudentID, Student);
    //        promisePut.then(function (pl) {
    //            $scope.Message = "Student Updated Successfuly";
    //            GetAllRecords();
    //            ClearModels();
    //        }, function (err) {
    //            console.log("Some Error Occured." + err);
    //        });
    //    }
    //};

    ////To Get Student Detail on the Base of Student ID  
    //$scope.get = function (Student) {
    //    var promiseGetSingle = CRUD_AngularJs_RESTService.get(Student.StudentID);
    //    promiseGetSingle.then(function (pl) {
    //        var res = pl.data;
    //        $scope.StudentID = res.StudentID;
    //        $scope.Name = res.Name;
    //        $scope.Email = res.Email;
    //        $scope.Class = res.Class;
    //        $scope.EnrollYear = res.EnrollYear;
    //        $scope.City = res.City;
    //        $scope.Country = res.Country;
    //        $scope.OperType = 0;
    //    },
    //              function (errorPl) {
    //                  console.log('Some Error in Getting Details', errorPl);
    //              });
    //}

    ////To Delete Record  
    //$scope.delete = function (Student) {
    //    var promiseDelete = CRUD_AngularJs_RESTService.delete(Student.StudentID);
    //    promiseDelete.then(function (pl) {
    //        $scope.Message = "Student Deleted Successfuly";
    //        GetAllRecords();
    //        ClearModels();
    //    }, function (err) {
    //        console.log("Some Error Occured." + err);
    //    });
    //}


  


});