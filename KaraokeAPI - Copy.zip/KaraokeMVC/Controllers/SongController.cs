﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KaraokeMVC.Models;

namespace KaraokeMVC.Controllers
{
    public class SongController : Controller
    {
        // GET: Song
        public string ConvertToUnsign1(string str)
        {
            string[] signs = new string[] {
            "aAeEoOuUiIdDyY",
            "áàạảãâấầậẩẫăắằặẳẵ",
            "ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
            "éèẹẻẽêếềệểễ",
            "ÉÈẸẺẼÊẾỀỆỂỄ",
            "óòọỏõôốồộổỗơớờợởỡ",
            "ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
            "úùụủũưứừựửữ",
            "ÚÙỤỦŨƯỨỪỰỬỮ",
            "íìịỉĩ",
            "ÍÌỊỈĨ",
            "đ",
            "Đ",
            "ýỳỵỷỹ",
            "ÝỲỴỶỸ"
        };
            for (int i = 1; i < signs.Length; i++)
            {
                for (int j = 0; j < signs[i].Length; j++)
                {
                    str = str.Replace(signs[i][j], signs[0][i - 1]);
                }
            }
            return str;
        }
        public ActionResult ListSong(string option = "", string search = "")
        {
            SongBusinessLayer s = new SongBusinessLayer();
            List<SongViewModel> lst = s.getListSong();
            if (option == "SoName")
            {
                List<SongViewModel> Searched = lst.Where(x => ConvertToUnsign1(x.SongName.ToLower()).Contains(ConvertToUnsign1(search).ToLower())).ToList();
                return View("ListSong", Searched);
            }
            else if (option == "SiName")
            {
                //List<SongViewModel> Searched = lst.Where(x => ConvertToUnsign1(x.ListSinger..ToLower()).Contains(ConvertToUnsign1(search).ToLower())).ToList();
                List<SongViewModel> Searched = new List<SongViewModel>();
                foreach(var i in lst)
                {
                    string temp = "";
                    foreach(var item in i.ListSinger)
                    {
                        temp =temp+" "+ item.SingerName;

                    }
                    if (ConvertToUnsign1(temp.ToLower()).Contains(ConvertToUnsign1(search).ToLower()))
                        Searched.Add(i);
                }
                return View("ListSong", Searched);
            }
            else
                return View("ListSong",lst);
        }

        [HttpGet]
        public ActionResult Create()
        {
            AuthorBusinessLayer AuBal = new AuthorBusinessLayer();
            GenreBusinessLayer GeBal = new GenreBusinessLayer();
            SingerBusinessLayer SiBal = new SingerBusinessLayer();
            ViewData["ListSinger"] = SiBal.GetListSinger();
            ViewData["ListAuthor"] = AuBal.GetListAuthor();
            ViewData["ListGenre"] = GeBal.GetGenre();
            return View();
        }
        [HttpPost]
        public ActionResult Create(SongCreate s, string _listID)
        {
            string[] list = _listID.Split(',');
            s.ListSinger = list;
            SongBusinessLayer SoBal = new SongBusinessLayer();
            SoBal.CreateSong(s);
            List<SongViewModel> lst = SoBal.getListSong();
            return View("ListSong", lst);
        }


        public ActionResult Delete(string id)
        {
            SongBusinessLayer SoBal = new SongBusinessLayer();
            SoBal.DeleteSong(id);
            List<SongViewModel> lst = SoBal.getListSong();
            return View("ListSong", lst);
        }


        [HttpGet]
        public ActionResult EditSong(string id)
        {
            AuthorBusinessLayer AuBal = new AuthorBusinessLayer();
            GenreBusinessLayer GeBal = new GenreBusinessLayer();
            SingerBusinessLayer SiBal = new SingerBusinessLayer();
            ViewData["ListSinger"] = SiBal.GetListSinger();
            ViewData["ListAuthor"] = AuBal.GetListAuthor();
            ViewData["ListGenre"] = GeBal.GetGenre();
            SongBusinessLayer SongBal = new SongBusinessLayer();
            List<SongViewModel> lst = SongBal.getListSong();
            return View(lst.Find(x => x.SongID == id));
        }
        [HttpPost]
        public ActionResult EditSong(SongCreate s, string _listID)
        {
            SongBusinessLayer SongBal = new SongBusinessLayer();
            SongBal.DeleteSong(s.SongID);
            string[] list = _listID.Split(',');
            s.ListSinger = list;
            SongBal.CreateSong(s);
            List<SongViewModel> lst = SongBal.getListSong();
            return View("ListSong", lst);
        }


        [HttpGet]
        public ActionResult Detail(string id)
        {
            SongBusinessLayer SongBal = new SongBusinessLayer();
            List<SongViewModel> lst = SongBal.getListSong();
            return View(lst.Find(x => x.SongID == id));
        }
    }
}