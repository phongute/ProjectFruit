﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeMVC.Areas.Admin.Models
{
    public class Author
    {

        public string AuthorID { get; set; }

        public string AuthorName { get; set; }
    }
}