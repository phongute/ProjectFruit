﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeMVC.Areas.Admin.Models
{
    public class Singer
    {

        public string SingerID { get; set; }


        public string SingerName { get; set; }

        public string Age { get; set; }
    }
}