﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace KaraokeMVC.Areas.Admin.Models
{
    public class GenreBusinessLayer
    {
        public string BASE_URL = "http://localhost:51535/api/";
        public List<Genre> GetGenre()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Genre").Result;
                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<List<Genre>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
        public List<Song> GetSongOfGenre(string id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Genre/"+id).Result;
                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<List<Song>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
    }
}