﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace KaraokeMVC.Areas.Admin.Models
{
    public class SingerBusinessLayer
    {
        public string BASE_URL = "http://localhost:51535/api/";
        public List<Singer> GetListSinger()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Singer").Result;
                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<List<Singer>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }


        public List<Song> GetSongOfSinger(string id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Singer/"+id).Result;
                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<List<Song>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }


        public bool CreateSinger(Singer s)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PostAsJsonAsync("Singer", s).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        public bool EditSinger(Singer s)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(BASE_URL);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.PutAsJsonAsync("Singer/" + s.SingerID, s).Result;
            return response.IsSuccessStatusCode;
        }

        public bool DeleteSinger(string id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("Singer/" + id).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}