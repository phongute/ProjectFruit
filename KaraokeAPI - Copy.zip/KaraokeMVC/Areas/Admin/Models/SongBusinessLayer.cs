﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace KaraokeMVC.Areas.Admin.Models
{
    public class SongBusinessLayer
    {
        public string BASE_URL = "http://localhost:51535/api/";
        public List<SongViewModel> getListSong()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Song").Result;
                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<List<SongViewModel>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
        public bool CreateSong(SongCreate s)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PostAsJsonAsync("Song", s).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }


        public bool DeleteSong(string id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("Song/" + id).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
        
        public bool EditSong(SongViewModel s)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(BASE_URL);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.PutAsJsonAsync("Song/" + s.SongID ,s).Result;
            return response.IsSuccessStatusCode;
        }

        public List<SongCreate> GetTopSong()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("Home").Result;
                if (response.IsSuccessStatusCode)
                    return response.Content.ReadAsAsync<List<SongCreate>>().Result;
                return null;
            }
            catch
            {
                return null;
            }
        }
    }
}