﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeMVC.Areas.Admin.Models
{ 
    public class Song
    {

        public string SongID { get; set; }

        public string SongName { get; set; }

        public string GenreID { get; set; }

        public DateTime? DatePost { get; set; }

        public int? ViewCount { get; set; }

    }
}