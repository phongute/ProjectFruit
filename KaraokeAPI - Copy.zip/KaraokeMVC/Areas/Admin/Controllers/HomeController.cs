﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KaraokeMVC.Areas.Admin.Models;
namespace KaraokeMVC.Areas.Admin.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult DisplaySong(string id)
        {
            SongBusinessLayer SongBal = new SongBusinessLayer();
            SongViewModel s = SongBal.getListSong().Find(x => x.SongID == id);
            
            return View(s);
        }
        //public ActionResult Index()
        //{
        //    SongBusinessLayer SongBal = new SongBusinessLayer();
        //    ViewData["TopSong"] = SongBal.GetTopSong();
        //    ViewData["ListSong"] = SongBal.getListSong();
        //    return View();

        //}
    }
}