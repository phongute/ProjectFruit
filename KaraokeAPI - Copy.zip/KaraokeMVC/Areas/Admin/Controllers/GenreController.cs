﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KaraokeMVC.Areas.Admin.Models;
namespace KaraokeMVC.Areas.Admin.Controllers
{ 
    public class GenreController : Controller
    {
        // GET: Genre
        public ActionResult GetSongOfGenre(string id)
        {
            GenreBusinessLayer GeBal = new GenreBusinessLayer();
            List<Song> lst = GeBal.GetSongOfGenre(id);
            return View(lst);
        }
    }
}