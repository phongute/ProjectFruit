﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KaraokeMVC.Models
{
    public class SongViewModel
    {
        public string SongID { get; set; }

        public string SongName { get; set; }

        public string GenreID { get; set; }

        public string GenreName { get; set; }

        public int? ViewCount { get; set; }

        public DateTime? DatePost { get; set; }

        public List<Singer> ListSinger { get; set; }

        public string AuthorID { get; set; }

        public string AuthorName { get; set; }
    }
}